const chalk = require('chalk')
const { red, blue } = chalk
console.log(red('hello'), blue('world!'))