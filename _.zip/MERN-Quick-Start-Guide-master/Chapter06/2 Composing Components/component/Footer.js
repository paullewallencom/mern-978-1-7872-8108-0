import React from 'react'
import ReactDOM from 'react-dom'

export default ({ date }) => (
	<footer>{date}</footer>
)
