import * as React from 'react'
import * as ReactDOM from 'react-dom'

export default () => (
	<p>This is a cool website designed with ReactJS</p>
)
