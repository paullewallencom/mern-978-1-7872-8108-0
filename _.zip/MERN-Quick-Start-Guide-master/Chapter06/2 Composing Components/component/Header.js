import React from 'react'
import ReactDOM from 'react-dom'

export default ({ title }) => (
	<h1>{title}</h1>
)
